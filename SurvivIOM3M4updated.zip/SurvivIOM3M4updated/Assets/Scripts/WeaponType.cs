public enum WeaponType
{
    None,
    Pistol,
    Shotgun,
    AR
}
